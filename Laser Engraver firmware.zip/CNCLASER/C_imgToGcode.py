from PIL import  Image, ImageOps
import os
PrecisionLaser = 10  # 10 pixels/mm
tailleMax = 90 * PrecisionLaser  # mm
pathfiltempo = "/home/pi/CNCLASER/tempo.gcode"
nbligne = 0
pathimage = ""  # /home/pi/CNCLASER/mire_grise.bmp"
# créer fichier tempo
f = open(pathfiltempo, "w")
coef = 1
MaxPowerLaser = 230
MinPowerLaser = 115
k = (MaxPowerLaser - MinPowerLaser) / 255


def EcritureGCODE(a, b):
    global nbligne, f
    # ecrir gcode
    f.write(a + "\n")
    f.write(b + "\n")
    # print(a)
    # print(b)
    nbligne += 2


def ConvColor(color):
    global coef, MaxPowerLaser, MinPowerLaser, k
    NG = 255 - int(color)
    NG = int(NG * k + MinPowerLaser)
    return NG

    
def ConvertImtoGCODE(file):
    global tailleMax, PrecisionLaser, nbligne
    im = Image.open(file)
    blanc = 255
    PixelColor = im.getpixel((1, 1))
    NG = 0
    bande = im.getbands()  # Returns a tuple containing the name of each band 
                        # in this image. For example, getbands on an RGB image returns (“R”, “G”, “B”).
    if len(bande) > 1:
        # im = Image.open(file).convert('L')
        im = ImageOps.grayscale(im)
        # print(im.getbands())
        print("image convertie en niveau de gris")
        # im.save('greyscale.png')
        # im2 = Image.open('greyscale.png')
        # print("new", im2.getbands())
    # color=getpixel((x,y)) #recup couleur pixel
    tailleX = im.width  # Image size, in pixels. The size is given as a 2-tuple (width, height).
    tailleY = im.height
    print("taille image x,y", tailleX, tailleY)
    if tailleX > tailleY:
        if tailleX > tailleMax:
            div = tailleX / tailleMax
            y = round(tailleY / div)
            im2 = im.resize((tailleMax, y), resample=PIL.Image.LANCZOS, box=None)
            im = im2.copy()
    else:
        if tailleY > tailleMax:
            div = tailleY / tailleMax
            x = round(tailleX / div)
            im2 = im.resize((x, tailleMax), resample=PIL.Image.LANCZOS, box=None)
            im = im2.copy()
            
    tailleX = im.width  # Image size, in pixels. The size is given as a 2-tuple (width, height).
    tailleY = im.height    
    offsetX = (tailleMax - tailleX) / 2 / PrecisionLaser
    offsetY = (tailleMax - tailleY) / 2 / PrecisionLaser
    print("taille image x,y", tailleX, tailleY)
    print("offset X,Y", offsetX, offsetY)
     
    # convertion
    # recherche premier point coloré
    print("Convertion en cours")
    a = 0
    b = 0
    stop = False
    for j in range(0, tailleY):  # * PrecisionLaser):
        for i in range(0, tailleX):  # * PrecisionLaser):
            # print(i, j, "couleur", im.getpixel((i, j)))
            col = im.getpixel((i, j))
            if col != blanc:
                a = i + 1
                b = j
                PixelColor = im.getpixel((i, j))
                # GCODEA = "M05"
                # GCODEB = "G00 X" + str(i) + " Y" + str(j)  # G00 ou G01 !
                # print("premier point X,Y,col", i, j, PixelColor)
                stop = True
                break  # premier point de la ligne
            # else:
            #    print("Blanc")
        if stop == True:
            break
        
    # print("etape 2 - point(x,y) (", 0, b, "),sens positif")
    # Scan de l'image, ligne par ligne,point par point
    for j in range(b, tailleY - 1, +2):  # * PrecisionLaser, 2):
        #----------------------------------------------------------------------------------------
        # sens positif    
        # premier point de la ligne 1
        # print("etape 2 - point(x,y) (", 0, b, "),sens positif")

        for i in range(0, tailleX):  # * PrecisionLaser):
            col = im.getpixel((i, j))
            if col != blanc:
                a = i + 1
                PixelColor = im.getpixel((i, j))
                NG = ConvColor(PixelColor)
                GCODEA = "M05"
                GCODEB = "G00 X" + str(i / PrecisionLaser + offsetX) + " Y" + str(j / PrecisionLaser + offsetY)  # G00 ou G01 !
                # print("premier point", PixelColor, i, j)
                # EcritureGCODE(GCODEA, GCODEB)
                break  # premier point de la ligne
        PixelColor = 255
        # les autres points de la ligne 1
        for i in range(a, tailleX):  # * PrecisionLaser):
            col = im.getpixel((i, j))
            if col != PixelColor:
                # print("a")
                EcritureGCODE(GCODEA, GCODEB)
                # nouveau point pour vecteur
                pointX = i
                pointY = j
                PixelColor = im.getpixel((i, j))
                # print("a: PixelColor", col, i, j)
                NG = ConvColor(PixelColor)
                
            else:
                # print("b : PixelColor", col, i, j)
                NG = ConvColor(PixelColor)
                if PixelColor == blanc:
                    GCODEA = "M05" 
                    GCODEB = "G00 X" + str((i + 1) / PrecisionLaser + offsetX) + " Y" + str(j / PrecisionLaser + offsetY)
                else:
                    GCODEA = "M03 S" + str(NG)
                    GCODEB = "G01 X" + str(i / PrecisionLaser + offsetX) + " Y" + str(j / PrecisionLaser + offsetY)
                
        '''        
        if PixelColor != blanc:
            print("c : PixelColor", col)
            GCODEA = "M03 S" + str(NG)
            GCODEB = "G01 X" + str(i) + " Y" + str(j)
            EcritureGCODE(GCODEA, GCODEB)
            PixelColor = blanc
        '''
        # print("etape 3 - ligne suivante (", j + 1, "), sens negatif")
        #----------------------------------------------------------------------------------------
        # sens negatif    
        # premier point de la ligne 2
        if (j + 1) >= tailleY:
            break
        PixelColor = blanc
        for i in range(tailleX - 1, 0, -1):
            col = im.getpixel((i, j + 1))
            if col != blanc:
                # print("d")
                a = i 
                # PixelColor = im.getpixel((i, j + 1))
                GCODEA = "M05"
                GCODEB = "G00 X" + str(i / PrecisionLaser + offsetX) + " Y" + str((j + 1) / PrecisionLaser + offsetY)  # G00 ou G01 !
                # print("premier point neg", col, i, j + 1)
                break  # premier point de la ligne
        PixelColor = 255
        # les autres points de la ligne 2
        for i in range(a, 0, -1):
            col = im.getpixel((i, j + 1))
            if col != PixelColor:
                # print("e: PixelColor", col, i, j + 1)
                EcritureGCODE(GCODEA, GCODEB)
                # nouveau point pour vecteur
                pointX = i
                pointY = j + 1
                PixelColor = im.getpixel((i, j + 1))
                NG = ConvColor(PixelColor)
            else:
                # print("f: PixelColor", col, i, j + 1)
                NG = ConvColor(PixelColor)
                if PixelColor == blanc:
                    GCODEA = "M05"
                    GCODEB = "G00 X" + str((i - 1) / PrecisionLaser + offsetX) + " Y" + str((j + 1) / PrecisionLaser + offsetY)
                else:
                    GCODEA = "M03 S" + str(NG)
                    GCODEB = "G01 X" + str(i / PrecisionLaser + offsetX) + " Y" + str((j + 1) / PrecisionLaser + offsetY)
                    
        '''
        if PixelColor != blanc:
            # print("g: PixelColor", i, j + 1, PixelColor)
            GCODEA = "M03 S" + str(NG)
            GCODEB = "G01 X" + str(i) + " Y" + str(j + 1)
            EcritureGCODE(GCODEA, GCODEB)
            PixelColor = blanc
        '''
    GCODEA = "M05"
    GCODEB = "G00 X" + str(90) + " Y" + str(5)
    EcritureGCODE(GCODEA, GCODEB)
    print("fin tratement image")
    f.close()
    return nbligne


'''
def main():
    pathimage = "/home/pi/CNCLASER/mire_grise.bmp"
    ConvertImtoGCODE(pathimage)
'''


'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/C_imgToGcode.py
'''

# main()

