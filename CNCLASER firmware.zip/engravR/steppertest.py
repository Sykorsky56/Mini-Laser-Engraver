# 	Simple Test Code for Rapsberry Pi Laser Engraver
#### original code ##########
# 	Ian D. Miller
# 	Jan 7, 2014
# 	http://www.pxlweavr.com
# 	info [at] pxlweavr.com
#### Modified code #############
#   https://github.com/iandouglas96/engravR
#### New version for python 3.5
#   Ludovic B.
#   august 2018
# /home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/engravR/steppertest.py
#   python 3.5

print ("Program Started")

import RPi.GPIO as GPIO
import Motor_control
from Bipolar_Stepper_Motor_Class import Bipolar_Stepper_Motor
import time
from numpy import pi, sin, cos, sqrt, arccos, arcsin

# Test program for steppenr motor
GPIO.cleanup()
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(32, GPIO.OUT, initial=GPIO.LOW)  # Enable motors
GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # FDC Xmax
GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # FDC Ymin
GPIO.setup(11, GPIO.OUT, initial=GPIO.LOW)  # ctrl laser
GPIO.setup(13, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # BP1
GPIO.setup(15, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # BP2
GPIO.setup(12, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # BP3

motorx = Bipolar_Stepper_Motor(31, 33, 35, 37)  # Motor X
motory = Bipolar_Stepper_Motor(16, 18, 22, 29)  # Motor y
directionx = 1
stepsx = 3000
directiony = -1
stepsy = 3000
'''
try:
    while (direction != 0):
        try:
            direction = int(input(("direction : ")))
        except :
            direction = 1
        try:
            steps = int(input("Step Number : "))
        except :
            steps = 0
        try:
            tmp = int(input("Laser state : "))
            if tmp == 1: laservar = True
            else: laservar = False
        except :
            laservar = False 

print("enabled\r")
GPIO.output(32, True)
motorx.move(directionx, stepsx, 0.001)
motorx.move(directionx, stepsx, 0.0008)
motorx.move(directionx, stepsx, 0.0006)
motorx.move(directionx, stepsx, 0.0004)
motorx.move(directionx, stepsx, 0.0002)
motory.move(directiony, stepsy, 0.001)
motory.move(directiony, stepsy, 0.0008)
motory.move(directiony, stepsy, 0.0006)
motory.move(directiony, stepsy, 0.0004)
motory.move(directiony, stepsy, 0.0002)
print("done\r")
'''
while (1):
    imput1 = GPIO.input(5)
    imput2 = GPIO.input(7)
    imput3 = GPIO.input(13)
    imput4 = GPIO.input(15)
    imput5 = GPIO.input(12)
    print(imput1, imput2, imput3, imput4, imput5)
    time.sleep(1)
# except KeyboardInterrupt:
GPIO.cleanup()  
