#!/usr/bin/env python3
# fstick.py
'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Test_USB.py
'''

from pyudev import Context, Device
context = Context()
import os
import time
import glob


def work():
    etat = 0
    # Runs the actual loop to detect the events 
    context = pyudev.Context()
    monitor = pyudev.Monitor.from_netlink(context)
    monitor.filter_by(subsystem='usb')
    # this is module level logger, can be ignored
    print("Starting to monitor for usb")
    monitor.start()
    for device in iter(monitor.poll, None):
        print("Got USB event: %s", device.action)
        if device.action == 'add':
            # some function to run on insertion of usb
            print("on_created()")
            etat = 1
            break
        else:
            # some function to run on removal of usb
            print("on_deleted()") 
            etat = 0
            break
    return etat

    
def lecture(etat):
    if etat == 1:
        print("ici")
        partitionsFile = open("/proc/partitions")
        lines = partitionsFile.readlines()[2:]  # Skips the header lines
        print('line', lines)
        for line in lines:
            words = [x.strip() for x in line.split()]
            minorNumber = int(words[1])
            deviceName = words[3]
            if minorNumber % 16 == 0:
                path = ("/sys/class/block/" + deviceName)
                print(path)
                if os.path.islink(path):
                    if os.path.realpath(path).find("/usb") > 0:
                        print ("/dev/%s" % deviceName)
                        f = open("/media/usb/demousb.txt", "r")
                        print(f.read(13))
                        f.close()

                        
def ListerFichier():
    global Liste, NbFichier
    # f=open('path to the list file',"w")
    for root, dirs, files in os.walk('/media/usb/'):
        for dir in dirs:
            for file in files:
                print(file)
                # f.write(os.path.join(root, file) + '\n')
                # f.close()

                
try:
    while(1):
        # sda = Device.from_name(context, 'block', 'sda')
        # print(sda)
        # for device in context.list_devices(subsystem='block'):
        #    print('{0} ({1})'.format(device.device_node, device.device_type))
        # lecture(1)
        # print(glob.glob("/media/usb/*.*"))
        # mylist = [f for f in glob.glob("/media/usb/*.txt")]
        ListeFichier = []
        x = [f.name for f in os.scandir("/media/usb/") if f.is_file()]
        for namefile in x:
            words = [x.strip() for x in namefile.split()]
            str1 = words[0]
            if str1.find(".nc") > -1:
                ListeFichier.append(str1)
            if str1.find(".gcode") > -1:
                ListeFichier.append(str1)
        print(ListeFichier[:])
        
        # ListerFichier()
        time.sleep(20)      
        
except KeyboardInterrupt:
    pass      

# https://docs.python.org/fr/3.5/library/subprocess.html

# subprocess.run(   
