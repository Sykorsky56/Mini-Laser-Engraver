
import time
from threading import Thread
import threading
import random
import sys
import os
from math import cos, sin, radians, pi
sys.path.append(os.path.abspath ("/home/pi/CNCLASER/engravR"))
import Motor_control
from Bipolar_Stepper_Motor_Class import Bipolar_Stepper_Motor
sys.path.append(os.path.abspath ("/home/pi/CNCLASER"))
import RPi.GPIO as GPIO
from numpy import pi, sin, cos, sqrt, arccos, arcsin
from pyudev import Context, Device
import glob
import C_imgToGcode as CITG
context = Context()
################################################################################################
#################                            ###################################################
#################    Parameters set up       ###################################################
#################                            ###################################################
################################################################################################
################################################################################################

'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''

filepath = "/media"
lignelue = 0
NameUSB = ""
filename = ""
filenameTest = "/home/pi/CNCLASER/Gcode_test.nc"
GPIO.setwarnings(False)
GPIO.cleanup()
# GPIO.setmode(GPIO.BCM) # deja déclaré dans luma.core
MY = Bipolar_Stepper_Motor(6, 13, 19, 26)  # 31, 33, 35, 37)  # pin number for a1,a2,b1,b2.  a1 and a2 form coil A b1 and b2 form coil B
MX = Bipolar_Stepper_Motor(23, 24, 25, 15)  # 16, 18, 22, 29)
sensMX = -1  # configure the true sens of rotation of motor
sensMY = -1  # configure the true sens of rotation of motor
sensAxeX = 1
sensAxeY = 1
PositionFindeCourseX = 51500  # 90mm
PinEnableMot = 12       
GPIO.setup(PinEnableMot, GPIO.OUT, initial=GPIO.LOW)  # Enable motors 32
Laser_switch = 18
GPIO.setup(Laser_switch, GPIO.OUT, initial=GPIO.LOW)  # ctrl laser 
p = GPIO.PWM(18, 200)  # channel et fréquence
# p.start(0)  # ici, rapport_cyclique vaut entre 0.0 et 100.0

debounce = 0.07  # attente anti-rebond
EtatFDC = False
BPpls = 22
BPmoi = 27
BPval = 17
FdcX = 2
FdcY = 14
GPIO.setup(BPpls, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # BP1 13
GPIO.setup(BPmoi, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # BP2 15
GPIO.setup(BPval, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # BP3 12
GPIO.setup(FdcX, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # FDC Xmax 
GPIO.setup(FdcY, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # FDC Ymin 
OldLaserStat = False
LaserPWM = 0

#################################################################################################
################################################################################################
#################                            ###################################################
#################    screen initialization   ###################################################
#################                            ###################################################
################################################################################################
################################################################################################
'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''

from luma.core.interface.serial import spi
from luma.core.render import canvas
from luma.lcd.device import uc1701x
from PIL import ImageFont, Image, ImageDraw
from luma.core.legacy.font import proportional, SINCLAIR_FONT, DEFAULT_FONT
from luma.core.virtual import viewport

font = ImageFont.truetype('/home/pi/CNCLASER/font/Aileron-Regular.otf', 8)

# DC = RS
serial = spi(port=0, device=0 , gpio_DC=21 , gpio_RST=20)  # , transfer_size=64, bus_speed_hz=500000)
# should be a value of 0, 1, 2 or 3 only, where 0 is no rotation, 1 is rotate 90 clockwise,
# 2 is 180 rotation and 3 represents 270 rotation.
device = uc1701x(serial, rotate=0)

path_or = os.path.abspath ("/home/pi/CNCLASER/icons")
img_path0 = path_or + '/logo laser.png'
logo = Image.open(img_path0)
background = Image.new("RGBA", device.size, "black")
background.paste(logo, (0, 0))
device.display(background.convert(device.mode))
backGraph = Image.open("/home/pi/CNCLASER/icons/engraving_fond.jpg")
fntGraph = ImageFont.truetype('/home/pi/CNCLASER/font/DSEG7ClassicMini-Bold.ttf', 23)
fnt2Graph = ImageFont.truetype('/home/pi/CNCLASER/font/DSEG7ClassicMini-Bold.ttf', 10)

from luma.core import legacy
from luma.core.virtual import history
from luma.core.image_composition import ImageComposition, ComposableImage

img_path1 = path_or + '/Graver.png'
img_path2 = path_or + '/configurer.png'
img_path3 = path_or + '/test.png'
img_path10 = path_or + '/Graver-sel.png'
img_path20 = path_or + '/configurer-sel.png'
img_path30 = path_or + '/test-sel.png'
# img_path4 = path_or + '/play.png'
# img_path5 = path_or + '/pause.png'
# img_path6 = path_or + '/stop.png'
# img_path40 = path_or + '/play-sel.png'
# img_path50 = path_or + '/pause-sel.png'
# img_path60 = path_or + '/stop-sel.png'
logo1 = Image.open(img_path1)
logo2 = Image.open(img_path2)
logo3 = Image.open(img_path3)
# logo4 = Image.open(img_path4)
# logo5 = Image.open(img_path5)
# logo6 = Image.open(img_path6)
logo10 = Image.open(img_path10)
logo20 = Image.open(img_path20)
logo30 = Image.open(img_path30)
# logo40 = Image.open(img_path40)
# logo50 = Image.open(img_path50)
# logo60 = Image.open(img_path60)

Fenetre_affichee = 0  # indique si la fenetre a ete affichee : 0=non 1=oui
etape = 0  # etape dans les menus
Fenetre = 0  # numero de la fenetre IHM courante
# 0 = Menu principal
# 1 = fenetre Graver
#         selection du fichier a imprimer dans une liste : une seule ligne est affichee
#         selectionner le materiaux : une seule ligne est affichee
#         confirmer le lancement de la gravure : BP+/BP- =oui,non BPval=confirme
# 2 = fenetre r�glages
#         reglage de SpeedEngravCustom
# 3 = fenetre test
#         un appui sur bp + = mvt diagonal + tete de 5 mm
#         un appui sur BP - = mvt diagonal - tete de 5mm
#         un appui sur BP validation = laser ON durant l'appui
#         un appui sur BP+ et BP- en meme temps = on sort du test
#         sur l'�cran, les BP et Fdc on leur etat affiche
#         position de la tete affichee
# 4 = fenetre en cours de gravure
#         indique le % d'avancement, le temps restant
#         un appui sur un des boutons entraine l'affichage de la page Play-Pause-Stop
# 5 = fenetre Play-Pause-Stop
#         un appui sur BP+ = selection incon suivant
#         un appui sur BP- = selection incon precedent
#         un appui sur BPvalid = execute le choix
#             play :  lancement gravure suaf si deja en cours alors rien
#             pause : met en pause et stop laser
#             stop : arrete la gravure et retourne au menu principal

Icon_sel = 0  # numero icon selectionne : 
# 0 = aucun
# 1 = fichier
# 2 = reglages
# 3 = test
# 4 = pause play stop

#######B#########################################################################################
################################################################################################
#################                            ###################################################
#################    Other initialization    ###################################################
#################                            ###################################################
################################################################################################
################################################################################################

Materiau = 0  # type de materiau, de 0 a xx
nom = ""
vitesse = 0
ListeMateriau = ["Très lent", "Lent", "Normal", "Très rapide", "Mode perso"]
VitesseMateriau = [0.1, 0.5, 2, 3, 2]  # defaut speed mm/s
PuissanceMateriau = [ 1, 1, 1, 1, 1]  # coef multiplicator
NbMateriau = 5
NumMateriauCustom = NbMateriau - 1
SpeedEngravCustom = 0
Echelle = 1
ListeFichier = []
NbFichier = 0
Nom_Fichier = ""
num_Fichier = 0
DetectUSB = False
etape_clavier = 0
Etat_process = 0  # 0=stop, 1=play, 2=pause
# tread : 0.7mm/tour (diam 4mm)
# stepper : Nema 8, 200 step/rot
# 0.7/200 = 0.0035 mm/step
dx = 0.00175  # resolution in x direction. Unit: mm/step
dy = 0.00175  # resolution in y direction. Unit: mm/step
PasSpeed = 0.1  # pas de vitesse (en mm/s ou autre ???)
MaxEngraving_speed = 3  # mm/s
Engraving_speed = 2.5  # mm/s
Moving_speed = 2.5  # mm/s
StartPause = 4.5  # secondes
speed = int(Engraving_speed / min(dx, dy))  # step/sec
fast_speed = int(Moving_speed / min(dx, dy))  # step/sec
print("fast_speed=", fast_speed)
print("graving speed", speed)
engraving = False
Alarm = ""
Etat_impression = 3  # Etat d'impression : play=1, pause=2, stop=3
PositionX = 0
PositionY = 0
TempsTotal = 0
TempsRestant = 0
Heur_debut_graver = 0

'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''

'''
def ConvImageGcode():
    im = Image.open('dead_parrot.jpg')  # Can be many different formats.
    pix = im.load()
    print (im.size)  # Get the width and hight of the image for iterating over
    print (pix[x, y])  # Get the RGBA Value of the a pixel of an image
'''


def Icon_gestion(sel, min, max):
    global Icon_sel
    if sel == 1 :
        Icon_sel = Icon_sel + 1
        if Icon_sel > max:
            Icon_sel = min
    if sel == -1 :
        Icon_sel = Icon_sel - 1        
        if Icon_sel < min:
            Icon_sel = max
	# affichage des icons et du carre de selection
    background = Image.new("RGBA", device.size, "black")
    draw = ImageDraw.Draw(background)
    draw.rectangle((0, 0, 127, 63), outline="white")        

    if Icon_sel == 1:
        # with canvas(device) as draw:
        background.paste(logo10, (15, 1))
        background.paste(logo2, (79, 1))
        background.paste(logo3, (46, 33))
    if Icon_sel == 2:
        # with canvas(device) as draw:
        background.paste(logo1, (15, 1))
        background.paste(logo20, (79, 1))
        background.paste(logo3, (46, 33))
    if Icon_sel == 3:
        # with canvas(device) as draw:
        background.paste(logo1, (15, 1))
        background.paste(logo2, (79, 1))
        background.paste(logo30, (46, 33))
        
       # sys.exit()
        
    device.display(background.convert(device.mode))
    # print("icon selectionne", Icon_sel)


def ListerFichier():
    global ListeFichier, NameUSB, filepath
    # only .nc and .gcode files (full path names) in a given directory
    try:
        ListeFichier.clear()
        for nameusb in os.listdir(filepath):
            path = os.path.join(filepath, nameusb)
            # print (path)
            # print("----------debut recherche fichiers-------------------")
            x = [f.name for f in os.scandir(filepath + "/" + nameusb) if f.is_file()]
            # print(x)
            for namefile in x:
                words = [x.strip() for x in namefile.split()]
                NameUSB = nameusb
                # print(words)
                str1 = words[0]
                if str1.find(".nc") > -1:
                    ListeFichier.append(str1)
                if str1.find(".gcode") > -1:
                    ListeFichier.append(str1)
                if str1.find(".jpg") > -1:
                    ListeFichier.append(str1) 
                if str1.find(".bmp") > -1:
                    ListeFichier.append(str1)                     
                if str1.find(".png") > -1:
                    ListeFichier.append(str1)                     
                       
        # print("----------liste-----------------------")
        i = 0
        for d in ListeFichier:
            print(i, ListeFichier[i])
            i += 1
        # print("-----------fin-----------------------")
    except:
        print("pas reussi a lire fichier")
        pass
    # print(ListeFichier[:])


def DetectCleUSB():
    global DetectUSB
	# detecter la cle usb et lister les fichiers ".nc"
    partitionsFile = open("/proc/partitions")
    lines = partitionsFile.readlines()[2:]  # Skips the header lines
    # print('line', lines)
    DetectUSB = False
    # print("Recherche clé usb")
    for line in lines:
        words = [x.strip() for x in line.split()]
        minorNumber = int(words[1])
        deviceName = words[3]
        if minorNumber % 16 == 0:
            path = ("/sys/class/block/" + deviceName)
            # print(path)
            if os.path.islink(path):
                if os.path.realpath(path).find("/usb") > 0:
                    # print ("/dev/%s" % deviceName)
                    DetectUSB = True
    if DetectUSB == True:
        print("clé usb trouvée")
        ListerFichier()
    else:
        print("pas de clé usb détectée")


def AfficherFichier(index):
    global DetectUSB, Fenetre_affichee, Icon_sel, num_Fichier, ListeFichier
    Fenetre_affichee = 1
    Icon_sel = 0
    etape = 0
    with canvas(device) as draw:
        draw.rectangle((0, 0, 127, 63), outline="white")
        draw.line((1, 15, 127, 15), fill="white")
        txt = "Fichiers (" + str(len(ListeFichier)) + ")"
        draw.text((10, 2), text=txt, fill="white")
        y = 0
        liste = ListeFichier.copy()
        print("num_Fichier :", num_Fichier)
        if DetectUSB == True:
            if num_Fichier >= 0 :
                for x in range(0, num_Fichier):
                    nom = liste[0]  # copie le 1er
                    # print("nom", nom, "numero", x)
                    del(liste[0])  # supprime le 1er
                    liste.append(nom)  # le met à la fin
                    # for h in liste:
                    #    print("new liste : ", h)
    
            for txt in liste:
                if y == 0:
                    # if index != 0:
                    draw.rectangle((3, 17, 127, 28), outline="white", fill="white")
                    draw.text((5, 17 + y), text=txt, fill="black")
                    # else:
                    #    draw.text((5, 17), text=txt, fill="white")  
                else :
                    draw.text((5, 17 + y), text=txt, fill="white")
                y += 10
            

def AfficherMateriau(index):
    global Fenetre_affichee, ListeMateriau, Materiau
    Fenetre_affichee = 1
    etape = 0
    with canvas(device) as draw:
        draw.rectangle((0, 0, 127, 63), outline="white")
        draw.line((1, 15, 127, 15), fill="white")
        txt = "Mode (" + str(len(ListeMateriau)) + ")"
        draw.text((10, 2), text=txt, fill="white")
        y = 0
        liste = ListeMateriau.copy()
        if Materiau >= 0 :
            for x in range(0, Materiau):
                nom = liste[0]  # copie le 1er
                # print("nom", nom, "numero", x)
                del(liste[0])  # supprime le 1er
                liste.append(nom)  # le met à la fin
                # for h in liste:
                #    print("new liste : ", h)

        for txt in liste:
            if y == 0:
                # if index != 0:
                draw.rectangle((3, 17, 127, 28), outline="white", fill="white")
                draw.text((5, 17 + y), text=txt, fill="black")
                # else:
                #    draw.text((5, 17), text=txt, fill="white")  
            else :
                draw.text((5, 17 + y), text=txt, fill="white")
            y += 10


def MsgBoxoui_non(index, msg):
    with canvas(device) as draw:
        draw.rectangle((0, 0, 127, 63), outline="white")
        if index == 1:
            draw.rectangle((13, 25, 60, 45), fill="white", outline="white")
            draw.rectangle((68, 25, 115, 45), fill="black", outline="white")
            txt = msg
            draw.text((5, 5), text=txt, fill="white")    
            txt = "Oui"
            draw.text((28, 30), text=txt, fill="black")
            txt = "Non"
            draw.text((80, 30), text=txt, fill="white")
            return True
        else:
            draw.rectangle((13, 25, 60, 45), fill="black", outline="white")
            draw.rectangle((68, 25, 115, 45), fill="white", outline="white") 
            txt = msg  
            draw.text((5, 5), text=txt, fill="white")    
            txt = "Oui"
            draw.text((28, 30), text=txt, fill="white")
            txt = "Non"
            draw.text((80, 30), text=txt, fill="black")          
            return False
    del draw


def Fichier_sel(index):
    global ListeFichier, num_Fichier, DetectUSB
    # selectionne le fichier slectionne
    DetectCleUSB()
    if DetectUSB == True:
        ListerFichier()
        num_Fichier = num_Fichier + index
        if num_Fichier < 0:
            num_Fichier = len(ListeFichier) 
        if num_Fichier > len(ListeFichier):
            num_Fichier = 0
        # print(len(ListeFichier))
        if len(ListeFichier) >= 0:
            AfficherFichier(index)
        else :
            return False
        if index == 0 :  # pas de fichier selectionne
            return False
        else :
            return True
    else :
        return False


def Materiau_sel(index):
    global ListeMateriau, Materiau
    # selectionne le materiau selectionne
    Materiau = Materiau + index
    if Materiau < 0:
        Materiau = NbMateriau - 1
    if Materiau > NbMateriau - 1 :
        Materiau = 0
    AfficherMateriau(Materiau)
    if index == 0 :  # pas de materiau selectionne
        return False
    else :
        return True


def VitessCustom(index):
    global PasSpeed, VitesseMateriau, NumMateriauCustom, Engraving_speed, MaxEngraving_speed
    VitesseMateriau[NumMateriauCustom] = VitesseMateriau[NumMateriauCustom] + PasSpeed * index
    # init si necessaire
    tmp = ""
    txt = Image.new("RGBA", device.size, "black")
    # get a font
    fnt = ImageFont.truetype('/home/pi/CNCLASER/font/DSEG7ClassicMini-Bold.ttf', 23)
    font2 = ImageFont.truetype('/home/pi/CNCLASER/font/Prototype.ttf', 15)

    # get a drawing context
    draw = ImageDraw.Draw(txt)
    draw.rectangle((0, 0, 127, 63), outline="white")

    if VitesseMateriau[NumMateriauCustom] < 0:
        VitesseMateriau[NumMateriauCustom] = 0 
        tmp = "00.0"
    elif VitesseMateriau[NumMateriauCustom] > MaxEngraving_speed:
        VitesseMateriau[NumMateriauCustom] = MaxEngraving_speed
    if (VitesseMateriau[NumMateriauCustom] < 10 and VitesseMateriau[NumMateriauCustom] > 0):
        tmp = "0" + str(int(VitesseMateriau[NumMateriauCustom] * 10) / 10)
    if VitesseMateriau[NumMateriauCustom] >= 10:
        tmp = str(int(VitesseMateriau[NumMateriauCustom] * 10) / 10)  

    tmp2 = "Engraving speed"
    draw.text((5, 1), tmp2, font=font2, fill="white")
    draw.line((0, 20, 128, 20), fill="white")
    draw.text((15, 29), tmp, font=fnt, fill="white") 
    draw.text((80, 32), "mm/s", font=font2, fill="white")
    device.display(txt.convert(device.mode))
    print("VitesseMateriau[NumMateriauCustom]", VitesseMateriau[NumMateriauCustom], NumMateriauCustom)
    return True


def NewEchelle(index):
    global Echelle
    # init si necessaire
    tmp = ""
    txt = Image.new("RGBA", device.size, "black")
    # get a font
    fnt = ImageFont.truetype('/home/pi/CNCLASER/font/DSEG7ClassicMini-Bold.ttf', 23)
    font2 = ImageFont.truetype('/home/pi/CNCLASER/font/Prototype.ttf', 15)

    # get a drawing context
    draw = ImageDraw.Draw(txt)
    draw.rectangle((0, 0, 127, 63), outline="white")

    if Echelle < 0:
        Echelle = 0 
        tmp = "00.0"
    elif Echelle > 30:
        Echelle = 30
    if (Echelle < 10 and Echelle > 0):
        tmp = "0" + str(int(Echelle * 10) / 10)
    if Echelle >= 10:
        tmp = str(int(Echelle * 10) / 10)  

    tmp2 = "Scale"
    draw.text((5, 1), tmp2, font=font2, fill="white")
    draw.line((0, 20, 128, 20), fill="white")
    draw.text((15, 29), tmp, font=fnt, fill="white") 
    draw.text((80, 32), "mm/s", font=font2, fill="white")
    device.display(txt.convert(device.mode))
    print("Echelle", Echelle)
    return True

		
def Clavier():
    global BPpls, etape_clavier , BPmoi, BPval, Fenetre, Icon_sel, Etat_impression
    global TempsRestant, Heur_debut_graver, TempsTotal, num_Fichier, Materiau
    global Fenetre_affichee, Engraving_speed, NumMateriauCustom, lignelue, Echelle
    tmp = False

	# Menu principal
    # print("clavier fenetre=", Fenetre)
    # print("etape_clavier", etape_clavier)
    if Fenetre == 0:
        if is_pressed(BPpls) == 0:
            Icon_gestion(1, 1, 3)
        if is_pressed(BPmoi) == 0:
            Icon_gestion(-1, 1, 3)
        if is_pressed(BPval) == 0:
            Fenetre = Icon_sel
            Fenetre_affichee = 0

    # fichier
    if Fenetre == 1:
        if etape_clavier == 0:
            DetectCleUSB()
            AfficherFichier(0)
            tmp = True
            while(DetectUSB == True):
                if is_pressed(BPpls) == 0:
                    tmp = Fichier_sel(1)
                elif is_pressed(BPmoi) == 0:
                    tmp = Fichier_sel(-1)
                elif is_pressed(BPval) == 0:
                    if tmp == False:
                        Fenetre = 0  # retour au menu principale
                        Fenetre_affichee = 0
                        time.sleep(0.5)
                        break
                    else:
                        etape_clavier = 1
                        time.sleep(0.5)
                        if DetectUSB == False:
                           etape_clavier = 0
                           Fenetre = 0  # retour au menu principale
                           Fenetre_affichee = 0 
                        break
        elif etape_clavier == 1:
            AfficherMateriau(0)
            tmp = True
            Materiau = 0
            while(Fenetre == 1):
                if is_pressed(BPpls) == 0:
                    tmp = Materiau_sel(1)
                elif is_pressed(BPmoi) == 0:
                    tmp = Materiau_sel(-1)
                elif is_pressed(BPval) == 0:
                    if tmp == False:
                        Materiau = 0  # par defaut
                    # configurer speed, etc... et lancer process
                    Fenetre_affichee = 0
                    while(Fenetre == 1):
                        time.sleep(0.5)
                        if Materiau == NumMateriauCustom:
                            tmp = VitessCustom(0)
                            sortie = False
                            while(sortie == False):
                                tmp = False
                                if is_pressed(BPpls) == 0: 
                                    tmp = VitessCustom(1)
                                elif is_pressed(BPmoi) == 0: 
                                    tmp = VitessCustom(-1)
                                elif is_pressed(BPval) == 0: 
                                    if tmp == True:
                                        Engraving_speed = VitesseMateriau[NumMateriauCustom]
                                    sortie = True
                                    # print("Engraving_speed", Engraving_speed)
                        else:
                            Engraving_speed = VitesseMateriau[Materiau]                                
                        Fenetre_affichee = 0
                        tmp = MsgBoxoui_non(0, "Lancer la gravure ?")
                        
                        while(1):
                            if is_pressed(BPpls) == 0:
                                tmp = MsgBoxoui_non(1, "Lancer la gravure ?")
                            elif is_pressed(BPmoi) == 0:
                                tmp = MsgBoxoui_non(-1, "Lancer la gravure ?")
                            elif is_pressed(BPval) == 0:
                                if tmp == False:
                                    # retour menu principale
                                    etape_clavier = 0
                                    Fenetre_affichee = 0
                                    Fenetre = 0
                                    # time.sleep(0.5)
                                    # print("retour menu")
                                    break
                                else:
                                    print("on imprime")
                                    # TempsTotal = CalculProcess()
                                    # lignelue = 0
                                    # print("TempsTotal", TempsTotal)
                                    # print('TempsRestant', TempsRestant)
                                    # Heur_debut_graver = 0
                                    # print("Heure debut", Heur_debut_graver)
                                    Fenetre = 4
                                    Fenetre_affichee = 0
                                    etape_clavier = 0                                
                                    break

    # Configurer
    # ajuste la valeur de speed du materiau custom
    if Fenetre == 2:
        tmp = False
        if is_pressed(BPpls) == 0: 
            tmp = VitessCustom(1)
        elif is_pressed(BPmoi) == 0: 
            tmp = VitessCustom(-1)
        elif is_pressed(BPval) == 0: 
            Fenetre = 0
            Fenetre_affichee = 0
            time.sleep(0.5)
            Engraving_speed = VitesseMateriau[NumMateriauCustom]
            print('engraving speed custom', Engraving_speed)
        '''
        tmp = False
        if is_pressed(BPpls) == 0: 
            tmp = NewEchelle(1)
        elif is_pressed(BPmoi) == 0: 
            tmp = NewEchelle(-1)
        elif is_pressed(BPval) == 0: 
            if tmp == False:
                Echelle = 1
            Fenetre = 0
            Fenetre_affichee = 0
            time.sleep(0.5)
            print('engraving speed custom', Engraving_speed)
        '''
    # tester
    if Fenetre == 3:
        cpt = 100
        tmp = False
        while(cpt != 0):
            cpt -= 1
            Fenetre_test(cpt)
            Fenetre_affichee = 0
            time.sleep(0.1)
        tmp = MsgBoxoui_non(0, "Lancer le teste ?")
        while(1):
            if is_pressed(BPpls) == 0:
                tmp = MsgBoxoui_non(1, "Lancer le teste ?")
            elif is_pressed(BPmoi) == 0:
                tmp = MsgBoxoui_non(-1, "Lancer le teste ?")
            elif is_pressed(BPval) == 0:
                if tmp == False:
                    # retour menu principale
                    etape_clavier = 0
                    Fenetre_affichee = 0
                    Fenetre = 0
                    # time.sleep(0.5)
                    print("retour menu")
                    break
                else:
                    Fenetre = 4
                    Fenetre_affichee = 0
                    etape_clavier = 0  
                    # tester
                    Engraving_speed = VitesseMateriau[NumMateriauCustom]
                    # filename = filenameTest  
                    # TempsTotal = CalculProcess(True)
                    # lignelue = 0
                    # Heur_debut_graver = 0
                    ExecutGcode(True) 
                    Fenetre = 0
                    Fenetre_affichee = 0                  
                    break

    # en cours de gravure
    if Fenetre == 4:
        ExecutGcode(False)
        Fenetre = 0
        Fenetre_affichee = 0


'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''


class Test_clavier(Thread):

    def __init__(self):
        Thread.__init__(self)

    def run(self):
        global BPval, BPpls, BPmoi , Etat_process, device, engraving, Laser_switch
        global LaserPWM
        while(Etat_process != 0):
            # print("thread")
            a = is_pressed(BPpls)
            b = is_pressed(BPmoi)
            c = is_pressed(BPval)
            if (a and b and c) == 0:
                while(1):
                    # print("--")
                    if a == 0:  # si play
                        # print("ici")
                        if Etat_process == 2:
                            if LaserPWM > 0:
                                laser = 1
                            else :
                                laser = 0
                            laseron(laser, LaserPWM)
                            # print('la')
                            # retour fenetre eu cours d'impression
                            # thread1.start()  # demarre le thread
                            Etat_process = 1  # play
                            Graphe(0)
                            print("play")
                        break
        
                    if b == 0:  # si pause
                        Etat_process = 2  # pause
                        laseron(0, 0)
                        Graphe(0, "En pause")
                        print("pause")
        
                    if c == 0:  # si stop
                        Etat_process = 0  # stop
                        laseron(0, 0)
                        # device.clear()
                        Graphe(0)
                        Graphe(0, "stopped")
                        print("stop")
                        time.sleep(5)
                        Fenetre_affichee = 0
                        Fenetre = 0
                        laseron(0, 0)
                        break
                    a = is_pressed(BPpls)
                    b = is_pressed(BPmoi)
                    c = is_pressed(BPval)


def Test_clavier2():
    global BPval, BPpls, BPmoi , Etat_process, device, engraving, Laser_switch
    global LaserPWM
    while(Etat_process != 0):
        # print("thread")
        a = is_pressed(BPpls)
        b = is_pressed(BPmoi)
        c = is_pressed(BPval)
        if (a and b and c) == 0:
            while(1):
                # print("--")
                if a == 0:  # si play
                    # print("ici")
                    if Etat_process == 2:
                        print("laser : ", engraving, LaserPWM)
                        if LaserPWM > 0:
                            laser = 1
                            print("Laser on")
                        else :
                            print("Laser off")
                            laser = 0
                        laseron(laser, LaserPWM)
                        # print('la')
                        # retour fenetre eu cours d'impression
                        # thread1.start()  # demarre le thread
                        Etat_process = 1  # play
                        Graphe(0)
                        print("play")
                    break
    
                if b == 0:  # si pause
                    Etat_process = 2  # pause
                    laseron(0, 0)
                    Graphe(0, "En pause")
                    print("pause")
    
                if c == 0:  # si stop
                    Etat_process = 0  # stop
                    laseron(0, 0)
                    # device.clear()
                    Graphe(0)
                    Graphe(0, "stopped")
                    print("stop")
                    time.sleep(5)
                    Fenetre_affichee = 0
                    Fenetre = 0
                    laseron(0, 0)
                    break
                a = is_pressed(BPpls)
                b = is_pressed(BPmoi)
                c = is_pressed(BPval)


def	Fenetre_principale():
    global Icon_sel, Fenetre_affichee

    # affichage
    if Fenetre_affichee == 0:
        # on affiche
        Fenetre_affichee = 1
        Icon_sel = 0
        # .....on dessine ici
        background = Image.new("RGBA", device.size, "black")
        draw = ImageDraw.Draw(background)
        draw.rectangle((0, 0, 127, 63), outline="white")        

        # posn = ((device.width - logo.width) // 2, 0)
        background.paste(logo1, (15, 1))
        background.paste(logo2, (79, 1))
        background.paste(logo3, (46, 33))
        device.display(background.convert(device.mode))
    # print ("fenetre principale affichee")


def	Fenetre_graver():
	# 1 = fenetre Graver
	# 		selection du fichier a imprimer dans une liste
	# 		selectionner le materiaux
	# 		confirmer le lancement de la gravure
    global Icon_sel, Fenetre_affichee
    # affichage
    if Fenetre_affichee == 0:
        # on affiche
        Fenetre_affichee = 1
        Icon_sel = 0
        etape = 0
        # .....on dessine ici
        DetectCleUSB()
        time.sleep(0.5)
        ListerFichier()

	
def	Fenetre_reglage():
    # 2 = fenetre reglages
    # reglage de SpeedEngravCustom
    global Icon_sel, Fenetre_affichee
    # affichage
    if Fenetre_affichee == 0:
        # on affiche
        Fenetre_affichee = 1
        Icon_sel = 0
        VitessCustom(0)


def	Fenetre_test(cpt):
	# 3 = fenetre test
	# 		un appui sur bp + = mvt diagonal + tete de 5 mm
	# 		un appui sur BP - = mvt diagonal - tete de 5mm
	# 		un appui sur BP validation = laser ON durant l'appui
	# 		un appui sur BP+ et BP- en meme temps = on sort du test
	# 		sur l'ecran, les BP et Fdc on leur etat affiche
	# 		position de la tete affichee
    global Icon_sel, Fenetre_affichee, FdcX, FdcY
    # affichage
    if Fenetre_affichee == 0:
        Fenetre_affichee = 1
        background = Image.new("RGBA", device.size, "black")
        draw = ImageDraw.Draw(background)
        draw.rectangle((0, 0, 127, 63), outline="white")
        # posn = ((device.width - logo.width) // 2, 0)
        a = "BP plus moins valide"
        b = "   " + str(GPIO.input(BPpls)) + "      " + str(GPIO.input(BPmoi)) + "      " + str(GPIO.input(BPval))
        d = "Fdc X " + str(GPIO.input(FdcX))
        e = "Fdc Y " + str(GPIO.input(FdcY))
        f = "Cycle : " + str(cpt)
        draw.text((2, 3), a, fill="white")
        draw.text((2, 15), b, fill="white")
        draw.text((2, 27), d, fill="white")
        draw.text((2, 39), e, fill="white")
        draw.text((2, 50), f, fill="white")
        device.display(background.convert(device.mode))

	
def Fenetre_encours():
    # 4 = Fenetre en cours d'impression
    global Icon_sel, Fenetre_affichee
    # affichage
    # on affiche 
    if Fenetre_affichee == 0:
        Fenetre_affichee = 1
        Icon_sel = 0
        Graphe(0)
	
	
def Menu():
	# 0 = Menu principal
	# 1 = fenetre Graver
	# 		selection du fichier a imprimer dans une liste
	# 		selectionner le materiaux
	# 		confirmer le lancement de la gravure
	# 2 = fenetre reglages
	# 		reglage de SpeedEngravCustom
	# 3 = fenetre test
	# 		un appui sur bp + = mvt diagonal + tete de 5 mm
	# 		un appui sur BP - = mvt diagonal - tete de 5mm
	# 		un appui sur BP validation = laser ON durant l'appui
	# 		un appui sur BP+ et BP- en meme temps = on sort du test
	# 		sur l'�cran, les BP et Fdc on leur etat affiche
	# 		position de la tete affichee
	# 4 = fenetre en cours de gravure
	# 		indique le % d'avancement, le temps restant
	# 		un appui sur un des boutons entraine l'affichage de la page Play-Pause-Stop
    global Fenetre
    if Fenetre == 0:
        Fenetre_principale()
    if Fenetre == 1:
        Fenetre_graver()
    if Fenetre == 2:
        Fenetre_reglage()
    if Fenetre == 3:
        Fenetre_test()
    if Fenetre == 4:
        Fenetre_encours()

   
def Graphe(init=1, message=""):
    # tp1 = time.time()

    global font, TempsRestant, Heur_debut_graver, TempsTotal
    global backGraph, fntGraph, fnt2Graph, engraving, lignelue
    # valeur comprise entre 0 et 100
    # Temps restant en minutes
    TempsRestant = TempsTotal - lignelue  # int((TempsTotal - time.time() + Heur_debut_graver) / 6) / 10.0
    # print("TempsRestant, TempsTotal, Heur_debut_graver, heure")
    # print(TempsRestant, int(TempsTotal / 6) / 10, Heur_debut_graver  , time.time()) 
    
    tmp1 = str(int(lignelue / 10))
    tmp2 = str(int(TempsTotal / 10))
    
    '''   
    if (TempsRestant < 10 and TempsRestant >= 0):
        tmp1 = "0" + str(TempsRestant)
    elif TempsRestant < 0:
        tmp1 = str(abs(TempsRestant))
    else:
        tmp1 = str(TempsRestant)
    
    # print('tmp1', tmp1)
    
    # Temps total en minutes
    temps_tot = int(TempsTotal / 6) / 10.0
    # print("temps_tot", temps_tot)
    if temps_tot < 10:
        tmp2 = "0" + str(temps_tot)
    else:
        tmp2 = str(temps_tot)
    '''
    
    # valeur in %
    if TempsTotal != 0:
        # valeur = int(((time.time() - Heur_debut_graver) / TempsTotal) * 100)
        valeur = int(lignelue / TempsTotal * 100) 
    else:
        valeur = 0
    if valeur > 99:
        tmp3 = "99"
        valeur = 100
    elif (valeur < 10 and valeur > 0):
        tmp3 = "0" + str(valeur)
    elif valeur <= 0:
        tmp3 = "00"
        valeur = 0
    else:
        tmp3 = str(valeur)
    
    rx = 31
    ry = 24
    dr1 = 3
    dr2 = 6
    dr3 = 8
    xmid = 64
    ymid = 32

    # get a drawing context
    if init == 0:
        backGraph = Image.open("/home/pi/CNCLASER/icons/engraving_fond.jpg")
        
    draw = ImageDraw.Draw(backGraph)
    # device.display(backGraph.convert(device.mode))
    # print("engraving state", engraving)
    if engraving == False:
        draw.ellipse((94, 1, 104, 10), outline="white", fill="black")
    else:
        draw.ellipse((94, 1, 104, 10), fill="white", outline="white")
        
    # draw.text((10, 10), "Hello", fill="white")
    # out = Image.alpha_composite(base, txt)
    # device.display(out.convert(device.mode))
    # time.sleep(5)
    if init == 0:
        # init du graph
        for i in range(1, 361, 20):
            x1 = (rx + dr1) * cos(radians(i - 1))
            y1 = (ry + dr1) * sin(radians(i - 1))
            x2 = (rx + dr3) * cos(radians(i - 1))
            y2 = (ry + dr3) * sin(radians(i - 1))            
            draw.line((x1 + xmid, y1 + ymid, x2 + xmid, y2 + ymid), fill="white", width=2)
        for i in range(1, 360, 5):
            x1 = (rx + dr1) * cos(radians(i - 1))
            y1 = (ry + dr1) * sin(radians(i - 1))
            x2 = (rx + dr2) * cos(radians(i - 1))
            y2 = (ry + dr2) * sin(radians(i - 1))            
            draw.line((x1 + xmid, y1 + ymid, x2 + xmid, y2 + ymid), fill="white", width=1)
        a = int(rx - 1)
        b = int(ry - 1)
        draw.ellipse((xmid - a, ymid - b, xmid + a, ymid + b), outline="white", fill=None)
    a = int(rx - 5)
    b = int(ry - 5)
    draw.ellipse((xmid - a, ymid - b, xmid + a, ymid + b), outline="white", fill="black")

    valeurdeg = valeur * 3.6  # convertie en degre
    # xy – Two points to define the bounding box. Sequence of [(x0, y0), (x1, y1)] or [x0, y0, x1, y1],
    # where x1 >= x0 and y1 >= y0.
    # start – Starting angle, in degrees. Angles are measured from 3 o’clock, increasing clockwise.
    # end – Ending angle, in degrees.
    # fill – Color to use for the arc.
    # cercle de 66x44 pixel
    # r arcs concentriques

    for r in range(1, 5):       
        a = int(rx - r)
        b = int(ry - r)
        # draw.line((1, 1, 10, 10), fill="white", width=1)
        draw.arc((xmid - a, ymid - b, xmid + a, ymid + b), 90 - valeurdeg, 90, fill=None)
        
    # text
    draw.rectangle((0, 50, 30, 64), fill="black")  # clear time
    draw.rectangle((0, 0, 30, 12), fill="black")  # clear time

    if TempsRestant < 0:
        draw.text((1, 53), "+", fill="white")
        draw.text((8, 53), tmp1, font=fnt2Graph, fill="white")   
    else:
        draw.text((1, 53), tmp1, font=fnt2Graph, fill="white")  
            
    draw.text((46, 21), tmp3, font=fntGraph, fill="white")
    draw.text((1, 1), tmp2, font=fnt2Graph, fill="white")
    
    if len(message) > 0:
        w, h = draw.textsize(message)
        a = int(128 - w) / 2
        draw.rectangle((1, 20, 128, 40), fill="white", outline="white")
        draw.text((a, 25), message, fill="black")
    device.display(backGraph.convert(device.mode))
    # tp2 = time.time()
    # print("temps graphe", tp2 - tp1)

            
def ACK_button():
    # attent un appui sur valide pour quitter et effacer ecran
    global debounce
    appui = 0
    while(appui == 0):
        test = GPIO.input(BPval)
        if test == 0:
            time.sleep(debounce)
            test = GPIO.input(BPval)
            if test == 0:
                appui = 1


def is_pressed(bp):
    # anti rebond
    global debounce
    appui = 0
    test = GPIO.input(bp)
    # print("test gpio", bp, " ", test)
    if test == 0:
        time.sleep(debounce)
        test = GPIO.input(bp)
        if test == 0:
            return 0
        else :
            return 1
    else :
        time.sleep(debounce)
        test = GPIO.input(bp)
        if test == 1:
            return 1
        else:
            return 1 


def Test_fdc():
    global FdcX, FdcY, Etat_process
    test = GPIO.input(FdcY)
    if test == 0:
        return True
    test = GPIO.input(FdcX)
    if test == 0:
        return True
    if Etat_process != 0:
        threading.Timer(0.5, Test_fdc).start()
    return False
        
################################################################################################
################################################################################################
#################                                ###############################################
#################    G code reading Functions    ###############################################
#################                                ###############################################
################################################################################################
################################################################################################


def XYposition(lines):
    # print("xy pos")
    # given a movement command line, return the X Y position
    # print(lines)
    xchar_loc = lines.index('X')
    # print("xchar_loc", xchar_loc)
    i = xchar_loc + 1
    while (47 < ord(lines[i]) < 58) | (lines[i] == '.') | (lines[i] == '-'):
        i += 1
    x_pos = float(lines[xchar_loc + 1:i])    
    # print("x_pos", x_pos)
    ychar_loc = lines.index('Y')
    # print("ychar_loc", ychar_loc)
    i = ychar_loc + 1
    while (47 < ord(lines[i]) < 58) | (lines[i] == '.') | (lines[i] == '-'):
        i += 1
    y_pos = float(lines[ychar_loc + 1:i])    
    # print("y_pos", y_pos)
    return x_pos, y_pos


def IJposition(lines):
    # print("ij pos")
    # given a G02 or G03 movement command line, return the I J position
    ichar_loc = lines.index('I')
    i = ichar_loc + 1
    while (47 < ord(lines[i]) < 58) | (lines[i] == '.') | (lines[i] == '-'):
        i += 1
    i_pos = float(lines[ichar_loc + 1:i])
    
    jchar_loc = lines.index('J')
    i = jchar_loc + 1
    while (47 < ord(lines[i]) < 58) | (lines[i] == '.') | (lines[i] == '-'):
        i += 1
    j_pos = float(lines[jchar_loc + 1:i]) 

    return i_pos, j_pos


def Motor_Step(MX, stepx, MY, stepy, speed):
    # tp1 = time.time()
    # return False is aborted
    global sensMX, sensMY, Alarm, PositionX, PositionY
    global PositionFindeCourseX, sensAxeX, sensAxeY
    global Etat_process, FdcX, FdcY
    
    # print("motor_step speed", speed)
    if abs(stepx) > 0:
        dirx = int(abs(stepx) / stepx)  # get dirction from the polarity of argument [step]
    else: 
        dirx = 1
    if abs(stepy) > 0:
        diry = int(abs(stepy) / stepy)
    else:
        diry = 1
    stepx = abs(stepx)    
    stepy = abs(stepy)   
    Total_step = sqrt((stepx ** 2 + stepy ** 2))
    TimeStep = Total_step / speed  # max(stepx, stepy) / speed  # Total_step / speed
    # print("Total_step=", Total_step, " step")
    # print("Temps total=", TimeStep , " s")
    # print("DirX=", dirx, " DirY=", diry)
    if Total_step > 57:  # environ 0.1mm
        if stepx < stepy:
            if abs(stepy) > 0:
                passtepx = stepx / stepy
            else:
                passtepx = 0
            passtepy = 1
            boucle = stepy
        elif stepx > stepy:
            if abs(stepx) > 0:
                passtepy = stepy / stepx
            else:
                passtepy = 0
            passtepx = 1        
            boucle = stepx
        elif stepx == stepy:
            passtepy = 1
            passtepx = 1       
            boucle = stepx     
    else:
            passtepy = stepy
            passtepx = stepx       
            boucle = 1 
    # print("boucle=", boucle)
    # print("passtepX=", passtepx)
    # print("passtepY=", passtepy)   
    j = 0
    k = 0
    epsil1 = 0
    epsil2 = 0
    epsil3 = 0
    epsil4 = 0
    l = 0.0
    m = 0.0
    f = 0.00035  # delai en - si axe en mouvement
    g = -0.000085  # delai en + si axe non en mvt
    # tp2 = time.time()
    # print("temps1", tp2 - tp1, "step", Total_step, "boucle", boucle)
    for i in range(1, boucle + 1):  
        while(Etat_process == 2):  # pause
            time.sleep(0.1)
        if Etat_process == 0:  # stop
            return False
        j = j + 1
        k = k + 1
        dt = 0.0000  # 0.0002075 à 0.5mm/s  # 0.0001405 à 3mm/s
        if (j >= passtepx and passtepx != 0):
            epsil1 = epsil2 + passtepx - j
            tmpx = int(epsil1 * 100000) / 100000  # permet d'éviter l'arrondi de 0.9999999999999999999 à une valeur de 1, entrainant un pas de trop
            l = l + j + tmpx
            if EtatFDC == False:
                MX.move(sensMX * dirx, int(l), 0)
                PositionX += dirx * int(l) * sensAxeX
            else:
                GPIO.output(PinEnableMot, False) 
                break
            epsil2 = epsil1 - tmpx
            l = l - int(l)
            j = 0
        if passtepx != 0:
            dt += f
        else:
            dt -= g
        if (k >= passtepy and passtepy != 0):
            epsil3 = epsil4 + passtepy - k
            tmpy = int(epsil3 * 100000) / 100000  # permet d'éviter l'arrondi de 0.9999999999999999999 à une valeur de 1, entrainant un pas de trop
            m = m + k + tmpy
            if EtatFDC == False:
                MY.move(sensMY * diry, int(m), 0)
                PositionY += diry * int(m) * sensAxeY
            else:
                GPIO.output(PinEnableMot, False) 
                break
            epsil4 = epsil3 - tmpy
            m = m - int(m)
            k = 0
        if (passtepy != 0):
            dt += f
        else:
            dt -= g
        tp3 = TimeStep / boucle - dt
        if tp3 < 0:
            tp3 = 0
        time.sleep(tp3)
    if EtatFDC == True:
        Alarm = "Fin de cours atteint"
        print("Alarme:", Alarm)
        if(GPIO.input(FdcY) == 0):
            PositionY = 0
        if(GPIO.input(FdcX) == 0):
            PositionX = 0
        return False
    tp3 = time.time()
    # print("temps1", tp2 - tp1, "temps2", tp3 - tp2, "step", Total_step)
    # print("-------------------------------------")
    return True
    # tp2 = time.time()
    # temps = tp2 - tp1
    # print("temps=", temps, " s")
    # vit = sqrt(PositionX ** 2 + PositionY ** 2) / temps * 0.00175
    # print("vitesse", vit)
    # print("temps/boucle", (tp2 - tp) * 1000000, " us")
    # print("vitesse consigne", fast_speed, " s")


def Moveto(MX, x_pos, dx, MY, y_pos, dy, speed, engraving):
    global fast_speed, PinEnableMot, PositionX, PositionY
    # GPIO.output(PinEnableMot, True)  # validation moteur
    stepx = (int(round(x_pos / dx)) - PositionX) * sensAxeX
    stepy = (int(round(y_pos / dy)) - PositionY) * sensAxeY
    Total_step = sqrt((stepx ** 2 + stepy ** 2))
    # print("moveto speed", speed)
    etat = True
    if Total_step > 0:
        # if engraving == False:  # fast movement
        #    print ('No Laser, fast movement: Dx=', stepx, '  Dy=', stepy, " at", fast_speed, "step/s")
        #    Motor_Step(MX, stepx, MY, stepy, fast_speed)
        # else:
        # print ('Laser on, movement: Dx=', stepx, '  Dy=', stepy, " at", speed, "step/s")
        etat = Motor_Step(MX, stepx, MY, stepy, speed)
    # GPIO.output(PinEnableMot, False)  # devalidation moteur
    # print("position X", PositionX)
    # print("position Y", PositionY)
    return etat

    
def laseron(etat, rp=0):  # When laser is turned on for the first time, pause a bit
    global engraving, Laser_switch, OldLaserStat, p, PuissanceMateriau, Materiau
    global StartPause
    if etat == 1:
        engraving = True
        rp = rp * PuissanceMateriau[Materiau]
        if rp > 100:
            rp = 100
        p.ChangeDutyCycle(rp)
        if OldLaserStat == False:        
            print("Laser on - time laser", rp, "%")
            
            p.start(100)  # ici, rapport_cyclique vaut entre 0.0 et 100.0
            time.sleep(StartPause)
            p.ChangeDutyCycle(rp)
        OldLaserStat = True
    else:
        engraving = False
        if OldLaserStat == True:
            print("laser off")
            p.stop()
        OldLaserStat = False
    
    # p = GPIO.PWM(channel, frequence)
    # p.start(rapport_cyclique)  # ici, rapport_cyclique vaut entre 0.0 et 100.0
    # p.ChangeFrequency(nouvelle_frequence)
    # p.ChangeDutyCycle(nouveau_rapport_cyclique)
    # p.stop()


def AvancementAnalyse(line):
    im = Image.new("RGBA", device.size, "black")
    draw = ImageDraw.Draw(im)
    txt = "Analyse " + str(line)
    w, h = draw.textsize(txt)
    a = int(128 - w) / 2
    draw.rectangle((1, 20, 128, 40), fill="white", outline="white")
    draw.text((a, 25), txt, fill="black")
    device.display(im.convert(device.mode))


'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''


def AnalyseGcode(test=False):
    global filepath, ListeFichier, num_Fichier, NameUSB
    global TempsTotal, lignelue, Heur_debut_graver
    # renvoi :
    # 1) le nom du fichier et son chemin
    # 2) si c'est une image (True)
    lignelue = 0
    Heur_debut_graver = 0
    ligne = 0
    if test == False:
        filename = filepath + "/" + NameUSB + "/" + ListeFichier[num_Fichier]
        print("filename:", ListeFichier[num_Fichier])        
        str1 = ListeFichier[num_Fichier]
        if str1.find(".jpg") > -1:
            AvancementAnalyse("en cours")
            TempsTotal = CITG.ConvertImtoGCODE(filename)
            filename = "/home/pi/CNCLASER/tempo.gcode"
            print("Nb lignes GCODE: ", TempsTotal)

            return filename, True
        if str1.find(".png") > -1:
            AvancementAnalyse("en cours")
            TempsTotal = CITG.ConvertImtoGCODE(filename)
            filename = "/home/pi/CNCLASER/tempo.gcode"
            print("Nb lignes GCODE: ", TempsTotal)
            return filename, True

        if str1.find(".bmp") > -1:
            AvancementAnalyse("en cours")
            TempsTotal = CITG.ConvertImtoGCODE(filename)
            filename = "/home/pi/CNCLASER/tempo.gcode"
            print("Nb lignes GCODE: ", TempsTotal)
            return filename, True

    else:
        filename = filenameTest
        print("filename:", filename)
    try:
        fd = open(filename, 'r')
        fd.seek(0, 0)
        # print("position debut", fd.tell())
        fd.seek(0, 2)
        print("position fin fichier", fd.tell())
        '''
        while fd.readline():
            ligne += 1
            AvancementAnalyse(ligne)
        TempsTotal = ligne
        '''
        TempsTotal = fd.tell()
    except:
        etape_clavier = 0
        Fenetre = 0  # retour au menu principale
        Fenetre_affichee = 0 
    return filename, False


'''
#   try:  # read and execute G code
    PosiExtimeX = PositionX
    PosiExtimeY = PositionY
    Total_step = 0
    TempsTotal = 0
    ligne = 0
    if test == False:
        speed = int(VitesseMateriau[Materiau] / min(dx, dy)) 
        filename = filepath + "/" + NameUSB + "/" + ListeFichier[num_Fichier]
        print("filename:", ListeFichier[num_Fichier])
    else:
        filename = filenameTest
        speed = int(VitesseMateriau[NumMateriauCustom] / min(dx, dy))
        print("filename:", filename)
    print('speed', speed)

    for lines in open(filename, 'r'):
        ligne += 1
        AvancementAnalyse(ligne)
        print(lines)
        # print(PosiExtimeX, PosiExtimeY)  
        # print("Total_step", Total_step)  
        # print("-------------------------")
        if lines[0:3] == 'G20':  # working in inch
            dx = dx / 25.4
            dy = dy / 25.4

        elif lines[0:3] == 'M03':
            TempsTotal += 3
            
        elif (lines[0:3] == 'G00') | (lines[0:3] == 'G1 ') | (lines[0:3] == 'G01'):  # |(lines[0:3]=='G02')|(lines[0:3]=='G03'):
            if (lines.find('X') != -1 and lines.find('Y') != -1):  # Ignore lines not dealing with XY plane
                # linear engraving movement
                x_pos, y_pos = XYposition(lines)
                # Moveto(MX, x_pos, dx, MY, y_pos, dy, speed, engraving)
                stepx = (int(round(x_pos / dx)) - PosiExtimeX) 
                stepy = (int(round(y_pos / dy)) - PosiExtimeY) 
                # print("Old posiX,posiY", PosiExtimeX, PosiExtimeY)
                PosiExtimeX += stepx
                PosiExtimeY += stepy
                Total_step = sqrt((stepx ** 2 + stepy ** 2))
                if engraving == False:
                    TempsTotal += Total_step / fast_speed
                else:
                    TempsTotal += Total_step / speed
                print("TempsTotal", TempsTotal)
                print("x_pos,y_pos", x_pos, y_pos)
                print("posiX,posiY", PosiExtimeX / dx, PosiExtimeY / dy)
                print("stepx,stepy,totalstep", stepx, stepy, Total_step)                
                print("------------------------------------")

        elif (lines[0:3] == 'G02') | (lines[0:3] == 'G2') | (lines[0:3] == 'G03') | (lines[0:3] == 'G3'):  # circular interpolation
            if (lines.find('X') != -1 and lines.find('Y') != -1 and lines.find('I') != -1 and lines.find('J') != -1):
                old_x_pos = x_pos
                old_y_pos = y_pos
                x_pos, y_pos = XYposition(lines)
                i_pos, j_pos = IJposition(lines)
                xcenter = old_x_pos + i_pos  # center of the circle for interpolation
                ycenter = old_y_pos + j_pos
            
                Dx = x_pos - xcenter
                Dy = y_pos - ycenter  # vector [Dx,Dy] points from the circle center to the new position
            
                r = sqrt(i_pos ** 2 + j_pos ** 2)  # radius of the circle
            
                e1 = [-i_pos, -j_pos]  # pointing from center to current position
                if (lines[0:3] == 'G02'):  # clockwise
                    e2 = [e1[1], -e1[0]]  # perpendicular to e1. e2 and e1 forms x-y system (clockwise)
                else:  # counterclockwise
                    e2 = [-e1[1], e1[0]]  # perpendicular to e1. e1 and e2 forms x-y system (counterclockwise)
    
                # [Dx,Dy]=e1*cos(theta)+e2*sin(theta), theta is the open angle
    
                costheta = (Dx * e1[0] + Dy * e1[1]) / r ** 2
                sintheta = (Dx * e2[0] + Dy * e2[1]) / r ** 2  # theta is the angule spanned by the circular interpolation curve
                    
                if costheta > 1:  # there will always be some numerical errors! Make sure abs(costheta)<=1
                    costheta = 1
                elif costheta < -1:
                    costheta = -1
    
                theta = arccos(costheta)
                if sintheta < 0:
                    theta = 2.0 * pi - theta
    
                no_step = int(round(r * theta / dx / 200))  # dx / 5.0))  # number of point for the circular interpolation
                
                for i in range(1, no_step + 1):
                    tmp_theta = i * theta / no_step
                    tmp_x_pos = xcenter + e1[0] * cos(tmp_theta) + e2[0] * sin(tmp_theta)
                    tmp_y_pos = ycenter + e1[1] * cos(tmp_theta) + e2[1] * sin(tmp_theta)
                    # Moveto(MX, tmp_x_pos, dx, MY, tmp_y_pos, dy, speed, True)
                    stepx = (int(round(tmp_x_pos / dx)) - PosiExtimeX)
                    stepy = (int(round(tmp_y_pos / dy)) - PosiExtimeY) 
                    # print("Old posiX,posiY", PosiExtimeX, PosiExtimeY)
                    # print("tmpx_pos,tmpy_pos", tmp_x_pos, tmp_y_pos)
                    # print("stepx,stepy", stepx, stepy)
                    PosiExtimeX += stepx
                    PosiExtimeY += stepy
                    Total_step = sqrt((stepx ** 2 + stepy ** 2))
                    TempsTotal += Total_step / speed
                    print("tempstotal", TempsTotal, "speed", speed)
                    print("posiX,posiY", PosiExtimeX, PosiExtimeY)
                    print("------------------------")                    
    
    # Moveto(MX, 5, dx, MY, 5, dy, fast_speed, False)  # move back to Origin
    stepx = (int(round(80 / dx)) - PosiExtimeX)
    stepy = (int(round(10 / dy)) - PosiExtimeY)
    Total_step += sqrt((stepx ** 2 + stepy ** 2))
    TempsTotal += Total_step / fast_speed
    PosiExtimeX += stepx
    PosiExtimeY += stepy
    
    # print(PosiExtimeX, PosiExtimeY)  
    # print("Temps total", TempsTotal, "secondes")  
    print("Temps total", TempsTotal , "s à ", speed, "mm/s") 
#    except :
#        print("probleme")
#        pass
    return TempsTotal    
'''
    
    
def ExecutGcode(test=False):
    global dx, dy, filepath, ListeFichier, num_Fichier, Laser_switch, engraving
    global MX, MY, speed, fast_speed, Alarm, Engraving_speed, sensAxeX, sensAxeY, sensMX, sensMY
    global Etat_process, filenameTest, FdcX, FdcY, OldLaserStat, LaserPWM, NameUSB
    global TempsTotal, lignelue, Heur_debut_graver
    # global PositionX, PositionY
    threading.Timer(0.5, Test_fdc).start()
    threading.Timer(0.5, Test_clavier2).start()
    GPIO.output(PinEnableMot, True)  # validation moteur
#   try:  # read and execute G code
    # Lancer les interruptions 
    OldLaserStat = False
    Etat_move = False 
    Etat_process = 1  
    # thread1 = Test_clavier()
    # thread1.start()  # demarre le thread
    filename, typeFile = AnalyseGcode(test)
    tempsprocess = time.time()
    
    if typeFile == False:
        speed = int(VitesseMateriau[Materiau] / min(dx, dy))
        filename = filepath + "/" + NameUSB + "/" + ListeFichier[num_Fichier]
        print("filename:", ListeFichier[num_Fichier])
    else:
        # pour une image
        speed = int(VitesseMateriau[Materiau] / min(dx, dy))
        print("filename:", filename)     
        
    if test == True:
        filename = filenameTest
        speed = int(VitesseMateriau[NumMateriauCustom] / min(dx, dy))
        print("filename:", filename)
    
    print('speed', speed)
    if GPIO.input(FdcX) == 0:
        MX.move(sensMX * 1 * sensAxeX, 600, 0.3 / fast_speed)
    if GPIO.input(FdcY) == 0:
        MX.move(sensMY * 1 * sensAxeY, 600, 0.3 / fast_speed)
    Graphe(0)
    no_step = 0
    # x_pos, y_pos = PositionX * dx, PositionY * dy
    # oldx_pos, oldy_pos = PositionX * dx, PositionY * dy
    # print(x_pos, y_pos)
    # (oldx_pos, oldy_pos)
    try:
        print("debut lecture")
        inputf = open(filename, 'r')
        for lines in inputf:
            
            lignelue += len(lines)
            # tp0 = time.time()
            
            if (len(Alarm) > 0):
                print("arret execut Gcode")
                Graphe(0, "arret execut Gcode")
                break
            while(Etat_process == 2):  # pause
                time.sleep(0.1)
            if Etat_process == 0:  # stop
                GPIO.output(PinEnableMot, False)  # validation moteur
                return False
            print("line: ", lines)
            Graphe(1)
            if lines == []:
                # blank lines
                pass
            elif lines[0:3] == 'G90':
                print ('start')
                
            elif lines[0:3] == 'G20':  # working in inch
                dx = dx / 25.4
                dy = dy / 25.4
        
                print ('Working in inch')
                  
            elif lines[0:3] == 'G21':  # working in mm
                # print("dx=", dx)
                print ('Working in mm')
                
            elif lines[0:3] == 'M05':
                laseron(0)
                if lines.find('S') != -1:
                    i = lines.index('S') + 1
                    StartPause = float(lines[i :i + 3]) / 100
            elif lines[0:3] == 'M03':
                if lines.find('S') != -1:
                    i = lines.index('S') + 1
                    LaserPWM = int(lines[i :i + 3]) / 2.55
                else: 
                    LaserPWM = 0
                laseron(1, LaserPWM)
        
            elif lines[0:3] == 'M02':
                laseron(0)
                print ('finished. shuting down')
                break
            elif (lines[0:3] == 'G1F') | (lines[0:4] == 'G1 F'):
                # do nothing
                pass
            elif (lines[0:3] == 'G00') | (lines[0:3] == 'G1 ') | (lines[0:3] == 'G01'):  # |(lines[0:3]=='G02')|(lines[0:3]=='G03'):
                if (lines.find('X') != -1 and lines.find('Y') != -1):  # Ignore lines not dealing with XY plane
                    # linear engraving movement
                    # oldx_pos = x_pos
                    # oldy_pos = y_pos
                    x_pos, y_pos = XYposition(lines)
                    if engraving == False:
                        # print("execute G00 fast speed", fast_speed)
                        Etat_move = Moveto(MX, x_pos, dx, MY, y_pos, dy, fast_speed, engraving)
                    else:
                        # print("execute G01 speed", speed)
                        Etat_move = Moveto(MX, x_pos, dx, MY, y_pos, dy, speed, engraving)
                
            elif (lines[0:3] == 'G02') | (lines[0:3] == 'G03') | (lines[0:2] == 'G2') | (lines[0:2] == 'G3'):  # circular interpolation
                if (lines.find('X') != -1 and lines.find('Y') != -1 and lines.find('I') != -1 and lines.find('J') != -1):
                    old_x_pos = x_pos
                    old_y_pos = y_pos
                    # oldx_pos = x_pos
                    # oldy_pos = y_pos
                    x_pos, y_pos = XYposition(lines)
                    i_pos, j_pos = IJposition(lines)
                    xcenter = old_x_pos + i_pos  # center of the circle for interpolation
                    ycenter = old_y_pos + j_pos
                
                    Dx = x_pos - xcenter
                    Dy = y_pos - ycenter  # vector [Dx,Dy] points from the circle center to the new position
                
                    r = sqrt(i_pos ** 2 + j_pos ** 2)  # radius of the circle
                
                    e1 = [-i_pos, -j_pos]  # pointing from center to current position
                    if (lines[0:3] == 'G02') | (lines[0:2] == 'G2'):  # clockwise
                        e2 = [e1[1], -e1[0]]  # perpendicular to e1. e2 and e1 forms x-y system (clockwise)
                    else:  # counterclockwise
                        e2 = [-e1[1], e1[0]]  # perpendicular to e1. e1 and e2 forms x-y system (counterclockwise)
        
                    # [Dx,Dy]=e1*cos(theta)+e2*sin(theta), theta is the open angle
        
                    costheta = (Dx * e1[0] + Dy * e1[1]) / r ** 2
                    sintheta = (Dx * e2[0] + Dy * e2[1]) / r ** 2  # theta is the angule spanned by the circular interpolation curve
                        
                    if costheta > 1:  # there will always be some numerical errors! Make sure abs(costheta)<=1
                        costheta = 1
                    elif costheta < -1:
                        costheta = -1
        
                    theta = arccos(costheta)
                    if sintheta < 0:
                        theta = 2.0 * pi - theta
        
                    no_step = int(round(r * theta / dx / 200))  # 5.0))  # number of point for the circular interpolation
                    # print("nb step", no_step)
                    # tp1 = time.time()        
                    for i in range(1, no_step + 1):
                        # tp0 = time.time()        
                        tmp_theta = i * theta / no_step
                        tmp_x_pos = xcenter + e1[0] * cos(tmp_theta) + e2[0] * sin(tmp_theta)
                        tmp_y_pos = ycenter + e1[1] * cos(tmp_theta) + e2[1] * sin(tmp_theta)
                        # print("Execute G02 G03 speed", speed)
                        # tp1 = time.time()        
    
                        Etat_move = Moveto(MX, tmp_x_pos, dx, MY, tmp_y_pos, dy, speed, True)
                        if Etat_move == False:
                            break  # arret suite demande abandon gravure
            # tp1 = time.time()        
            # distx = int(x_pos - oldx_pos) * sensAxeX
            # disty = int(y_pos - oldy_pos) * sensAxeY
            # Total_dist = sqrt((distx ** 2 + disty ** 2))
            # print("x,y", x_pos, y_pos)
            # print("old x,y", oldx_pos, oldy_pos)
            # print(distx, disty)
            # print("temps ligne", round((tp1 - tp0) * 100) / 100, "s vitesse (", round(speed * dx), ") ", round(Total_dist / (tp1 - tp0) * 100) / 100, " mm/s dist", round(Total_dist * 100) / 100, 'mm')
            # print("-------------------------------------------------------")     
    except:    
        etape_clavier = 0
        Fenetre = 0  # retour au menu principale
        Fenetre_affichee = 0 
    
    laseron(0)
    Graphe(0)
    # print("Laser off")
    if Etat_move == True:
        Origine() 
#    except :
#        print("probleme")
#        pass
    print("position", PositionX)
    print("position", PositionY)
    Graphe(0)
    tempsfin = time.time()
    print("Durée process=", tempsfin - tempsprocess, " s")
    Graphe(0, "Impression terminée")
    Etat_process = 0
    GPIO.output(PinEnableMot, False)  # validation moteur
    time.sleep(4)


'''
def ManualControl():
    # xsteps = int(raw_input("X Stepper Steps: "))
    # ysteps = int(raw_input("Y Stepper Steps: "))
    # laservar = int(raw_input("Laser state (1 on, 0 off): "))
    # GPIO.output(Laser_switch, laservar)
    if (xsteps > 0):
        MX.move(1, abs(xsteps), 0.01)
    else:
        MX.move(-1, abs(xsteps), 0.01)
    if (ysteps > 0):
        MY.move(1, abs(ysteps), 0.01)
    else:
        MY.move(-1, abs(ysteps), 0.01)
'''

        
def Origine():
    global sensMX, sensMy, fast_speed, PositionX, PositionY
    global sensAxeY, sensAxeX, Alarm, FdcX, FdcY
    # GPIO.setup(3, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # FDC Xmax 5
    # GPIO.setup(14, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # FDC Ymin 7
    GPIO.output(PinEnableMot, True)
    etape = 0
    cpt = 0
    
    # MX.move(sensMX * -1, 10000, 0.0008) 
    # MY.move(sensMY * 1, 20000, 0.0008) 
    # while(1):
    print("Fdc Xmax=", GPIO.input(FdcX))
    print("Fdc Ymin=", GPIO.input(FdcY))
    # print("fast_speed=", fast_speed)
    # time.sleep(10.5)
    
    for i in range (1, 12000):
        test1 = GPIO.input(FdcX)
        if (test1 == 1):
            if (etape == 0):
                # cpt += 10
                MX.move(sensMX * 1 * sensAxeX, 10, 0.3 / fast_speed)  
        if (test1 == 0):
            if (etape == 0):
                etape = 1
        if etape == 1:
            cpt = 200
            MX.move(sensMX * -1 * sensAxeX, 600, 0.3 / fast_speed)
            etape = 3
            # print("etape", etape)
        ''' 
        if (etape == 1 and cpt <= 58000):
            cpt += 10
            MX.move(sensMX * 1, 10, 0.3 / fast_speed) 
            print("cpt", cpt)            
        if cpt >= 58000:
            etape = 3
            # print("etape", etape)
        '''
        test2 = GPIO.input(FdcY)  
        if (test2 == 1):
            MY.move(sensMY * -1 * sensAxeY, 10, 0.8 / fast_speed) 
        '''    
            test2 = GPIO.input(14) 
            if (test2 == 0):
                print("fin origine Y")
        '''        
        
        if (etape == 3 and test2 == 0):
            print("fin origine")
            break
        
    PositionX = PositionFindeCourseX
    PositionY = 0
    # print("cpt", cpt)
    # MX.move(sensMX * 1, 400, 2 / fast_speed) 
    MY.move(sensMY * 1 * sensAxeY, 600, 2 / fast_speed)
    GPIO.output(PinEnableMot, False)
    Alarm = ""
    print("Fdc Xmax=", GPIO.input(FdcX))
    print("Fdc Ymin=", GPIO.input(FdcY))
    
###########################################################################################
###########################################################################################
#################                           ###############################################
#################    Main program           ###############################################
#################                           ###############################################
###########################################################################################
###########################################################################################


'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''


def main():
    global Laser_switch, context, NumMateriauCustom, VitesseMateriau

    Origine() 
    DetectCleUSB()
    # VitesseMateriau[NumMateriauCustom] = 4
    # ExecutGcode(True)
    # time.sleep(100)
    ListerFichier()
    # filename = filepath + "/" + NameUSB + "/" + ListeFichier[44]

    # TempsTotal = CITG.ConvertImtoGCODE(filename)
    
    while(1):
        Menu()
        Clavier()
    print("fin")
    GPIO.output(Laser_switch, False)


'''
/home/pi/CNCLASER/cv/bin/python3.5 /home/pi/CNCLASER/Main_draft.py
'''

    
if __name__ == "__main__":


    try:


        main()


    except KeyboardInterrupt:
        print("Fin du programme")

