# 	Simple Test Code for Rapsberry Pi Laser Engraver
#### original code ##########
# 	Ian D. Miller
# 	Jan 7, 2014
# 	http://www.pxlweavr.com
# 	info [at] pxlweavr.com
#### Modified code #############
#   https://github.com/iandouglas96/engravR
#### New version for python 3.5
#   Ludovic B.
#   august 2018
# /root/.virtualenvs/cv/bin/python3.5 /home/pi/CNCLASER/engravR/steppertest.py
#   python 3.5

print ("Program Started")

import RPi.GPIO as GPIO
import Motor_control
from Bipolar_Stepper_Motor_Class import Bipolar_Stepper_Motor
import time
from numpy import pi, sin, cos, sqrt, arccos, arcsin

# Test program for steppenr motor
GPIO.cleanup()
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(12, GPIO.OUT)  # Enable

motor = Bipolar_Stepper_Motor(6, 13, 19, 26)
motor2 = Bipolar_Stepper_Motor(23, 24, 25, 15)
direction = -1
steps = 1
'''
try:
    while (direction != 0):
        try:
            direction = int(input(("direction : ")))
        except :
            direction = 1
        try:
            steps = int(input("Step Number : "))
        except :
            steps = 0
        try:
            tmp = int(input("Laser state : "))
            if tmp == 1: laservar = True
            else: laservar = False
        except :
            laservar = False
'''
print("enabled\r")
# motor2.move(direction, 100, 1)
motor.move(direction, 10000, 0.001)

# except KeyboardInterrupt:
# GPIO.cleanup()  
